package config

import "time"

var ElevatorAddresses = map[int]string{
	1: "localhost:7331",
	2: "localhost:7332",
	3: "localhost:7333",
}

const (
	HeartBeatInterval          = 10 * time.Millisecond
	WorldviewBCInterval        = 20 * time.Millisecond
	ResendInterval             = 10 * time.Millisecond
	Timeout                    = 1000 * time.Millisecond
	QueryMasterTimer           = 2000 * time.Millisecond
	MsgTimeout                 = 2000 * time.Millisecond
	TimeBetweenFloorsThreshold = 5000 * time.Millisecond
	DoorOpenThreshold          = 5000 * time.Millisecond
	MasterTimeout              = 1000 * time.Millisecond
	ElevatorInitTimeout        = 1000 * time.Millisecond
	OrderCalculationPeriod     = 100 * time.Millisecond

	BCport  = 15500
	P2Pport = 16000

	NumFloors = 4
)

var IsMaster = false
var CurrentMasterID = -1
var ElevatorID = 0
